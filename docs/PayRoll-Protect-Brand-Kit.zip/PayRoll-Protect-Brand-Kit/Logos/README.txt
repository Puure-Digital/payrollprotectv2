﻿PayRoll Protect logo masters. Transparent PNG, 6250 x 6250 px (logo centred on a square canvas; crop as needed).

PayRoll-Protect-logo-light-for-dark-backgrounds.png  White wordmark, green shield. Use on dark grounds and footage.
PayRoll-Protect-logo-dark-for-light-backgrounds.png  Charcoal wordmark, green shield. Use on light grounds.
PayRoll-Protect-shield-icon.png                      Shield only, for small spaces.

Don't recolour, redraw, stretch, outline, or add shadows or glows. See the brand kit PDF.
