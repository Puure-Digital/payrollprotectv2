PayRoll Protect fonts. Both are free under the SIL Open Font License 1.1 (see OFL.txt in each folder).

Mona Sans (headlines, body, figures) - official release v2.0.27, github.com/github/mona-sans
  MonaSansVF-Expanded[...].ttf  Expanded width only. Use this for headlines and captions:
                                weight 330 (or the Light instance if your app can't set axes).
  MonaSansVF[wdth,...].ttf      All widths. Titles and figures use width 112.5 (SemiExpanded),
                                body text width 100.

Geist Mono (labels, IDs, data) - official release v1.8.2, github.com/vercel/geist-font
  GeistMono-Medium.otf   Labels: uppercase, +10% tracking.
  GeistMono-Regular.otf  Data and IDs.

Full settings are on the Type page of the brand kit PDF.
